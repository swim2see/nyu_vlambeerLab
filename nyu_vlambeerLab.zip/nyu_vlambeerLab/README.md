nyu_vlambeerLab

![](http://www.vlambeer.com/wp-content/uploads/2013/04/level3.gif)

# INTRO TO PROC GEN LAB
- FORK the repo to your account, then CLONE your fork to your laptop (copy the ".git" URL from the green button, and then select "Clone" in GitKraken)
- open the project folder in Unity, open Assets/scripts/Pathmaker.cs, read the instructions
- you will be making something kind of like [what Vlambeer did for "Nuclear Throne"](http://rami-ismail.squarespace.com/blog/2013/04/02/random-level-generation-in-wasteland-kings)
- EXAMPLE FROM PAST SEMESTER: https://rahuljoshi.itch.io/floor-generator?secret=dadn6bQ43QKOu0uNqd101Cayw
